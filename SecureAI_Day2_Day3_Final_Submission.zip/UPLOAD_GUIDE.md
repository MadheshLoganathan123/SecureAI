# UPLOAD_GUIDE.md � Where Every File Should Be Submitted

---

## A. KAGGLE WRITEUP CONTENT

| File | Why Needed | Where | Required? |
|------|-----------|-------|-----------|
| `writeup/WRITEUP_FINAL.md` | Paste into Kaggle Project Description field | Kaggle writeup editor | **REQUIRED** |
| `writeup/TITLE.txt` | Paste into Kaggle Title field | Kaggle writeup editor | **REQUIRED** |
| `writeup/SUBTITLE.txt` | Paste into Kaggle Subtitle field | Kaggle writeup editor | **REQUIRED** |
| `writeup/SUBMISSION_TRACK.txt` | Select "Advanced" in Track dropdown | Kaggle writeup editor | **REQUIRED** |

---

## B. KAGGLE MEDIA GALLERY

| File | Why Needed | Where | Required? |
|------|-----------|-------|-----------|
| `writeup/cover_card.jpg` (resize to 560x280) | Thumbnail card shown in competition gallery | Kaggle Card/Thumbnail upload | **REQUIRED** |
| `final_submission/figures/f1_comparison.png` | Before/after F1 comparison across all methods | Kaggle Media Gallery | STRONGLY RECOMMENDED |
| `final_submission/figures/f1_over_rounds.png` | Shows convergence across 8 federated rounds | Kaggle Media Gallery | STRONGLY RECOMMENDED |
| `final_submission/figures/confusion_matrix.png` | Final model confusion matrix on KDDTest+ | Kaggle Media Gallery | STRONGLY RECOMMENDED |
| `final_submission/figures/client_distribution.png` | Non-IID client partition visualization | Kaggle Media Gallery | RECOMMENDED |

---

## C. KAGGLE NOTEBOOK

| File | Why Needed | Where | Required? |
|------|-----------|-------|-----------|
| `final_submission/final_notebook.ipynb` | Official Day 2 notebook submission; must be run with visible outputs | Kaggle Notebook submission | **REQUIRED** |

> IMPORTANT: Upload `final_notebook.ipynb` to Kaggle, run it there so all cell outputs are recorded and visible. The notebook is self-contained and imports from `src/pipeline.py`.

---

## D. GITHUB REPOSITORY

| File | Why Needed | Where | Required? |
|------|-----------|-------|-----------|
| `README.md` | Project overview and reproduction instructions | GitHub repo root | **REQUIRED** |
| `requirements.txt` | Dependency specification | GitHub repo root | **REQUIRED** |
| `src/__init__.py` | Python package init | `src/` | **REQUIRED** |
| `src/pipeline.py` | Complete reproducible pipeline (737 lines) | `src/` | **REQUIRED** |
| `final_submission/model_scripted.pt` | TorchScript exported model (10.3 KB) | `artifacts/` or `final_submission/` | **REQUIRED** |
| `final_submission/submission.json` | Hackathon metadata and declared metrics | `artifacts/` or `final_submission/` | **REQUIRED** |
| `final_submission/final_notebook.ipynb` | Executable notebook | `notebook/` or `final_submission/` | **REQUIRED** |
| `final_submission/figures/*.png` | All 4 result figures | `final_submission/figures/` | RECOMMENDED |
| `final_submission/experiment_results.csv` | Full experiment audit log E001-E004 | `final_submission/` | RECOMMENDED |
| `final_submission/final_metrics.json` | Full metric JSON with all confusion matrices | `final_submission/` | RECOMMENDED |
| `final_submission/ablation_study.csv` | 5-stage ablation results | `final_submission/` | RECOMMENDED |
| `final_submission/multi_seed_results.csv` | 5-seed stability results | `final_submission/` | RECOMMENDED |
| `final_submission/advanced_final_comparison.csv` | Advanced track attack vs defense benchmark | `final_submission/` | RECOMMENDED |
| `final_submission/client_analysis.csv` | Per-client partition telemetry | `final_submission/` | RECOMMENDED |
| `validate_final_submission.py` | Automated submission validator | repo root | RECOMMENDED |
| `writeup/WRITEUP_FINAL.md` | Written writeup documentation | `writeup/` or `docs/` | OPTIONAL |
| `writeup/VIDEO_SCRIPT.md` | Video presentation script | `writeup/` or `docs/` | OPTIONAL |

### Files NOT to upload to GitHub

| File | Reason |
|------|--------|
| `test_public.csv` | 12 MB � large challenge file; link to Kaggle instead |
| `data/KDDTrain+.txt` | 19 MB � pipeline auto-downloads |
| `data/KDDTest+.txt` | 3.4 MB � pipeline auto-downloads |
| `final_submission/submission.csv` | 124 KB predictions � not part of source code |
| `sample_submission.csv` | Challenge format reference only |
| `__pycache__/` | Build cache, exclude via .gitignore |
| `src/__pycache__/` | Build cache, exclude via .gitignore |
| `final_submission.zip` | Already in repo; don't double-include |
| `baseline_audit.json` | Internal debug file, 18 KB |
| `full_optimization_suite.json` | Internal experiment file |
| `audit_baseline.py` | Internal diagnostic script |
| `debug_detection.py` | Internal debug script |
| `diagnose_pipeline.py` | Internal diagnostic script |
| `feature_audit.py` | Internal utility |
| `experiment_engine.py` | Internal experimentation engine |
| `run_ablation.py` | Internal script (results already in CSV) |
| `run_full_optimization_suite.py` | Internal script |
| `test_defense_and_tuning.py` | Internal test script |

---

## E. VIDEO (3 minutes max)

| Item | Specification |
|------|--------------|
| Script | `writeup/VIDEO_SCRIPT.md` |
| Max length | 3 minutes (180 seconds) |
| Format | Screen recording + narration |
| Must be | Public (YouTube or similar) |
| Required? | **REQUIRED** |

---

## F. OPTIONAL SUPPORTING MATERIAL

| File | Description | Useful For |
|------|-------------|-----------|
| `final_submission/intermediate_final_comparison.csv` | Intermediate track benchmark | Completeness |
| `final_submission/final_client_generalization.csv` | Per-client local F1/recall | Technical depth |
| `agg_search_results.csv` | Aggregation hyperparameter search | Ablation evidence |
| `arch_search_results.csv` | Architecture search results | Ablation evidence |

---

## G. FILES THAT SHOULD NOT BE UPLOADED ANYWHERE

| File | Reason |
|------|--------|
| Any `.env` or config with tokens | Security |
| `__pycache__` directories | Build artifacts |
| `baseline_audit.json` (18 KB) | Internal debug only |
| Large raw datasets | Too large; auto-downloaded |
