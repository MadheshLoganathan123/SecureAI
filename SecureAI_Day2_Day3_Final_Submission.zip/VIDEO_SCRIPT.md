# VIDEO_SCRIPT.md � 3-Minute Presentation Script
# CAIRLab Secure AI Hackathon 2026 � Advanced Track

**Total target time: 2:45 � 3:00 minutes**
**Format: Screen recording + voice narration**

---

## [0:00 - 0:20] OPENING � Problem Statement

**Show on screen:** Cover card image (hackathon_cover_card.jpg)

**Narration:**
"In this submission for the CAIRLab Secure AI Hackathon 2026 Advanced Track, we tackle one of the hardest challenges in federated learning: building an intrusion detection system that remains accurate even when one of the participating clients is actively trying to poison the shared model.

The dataset is NSL-KDD, simulating network traffic across five distributed client institutions with severely unequal data distributions."

---

## [0:20 - 0:45] BASELINE FAILURE � Why FedAvg Breaks

**Show on screen:** f1_comparison.png (side by side: FedAvg clean vs FedAvg under attack)

**Narration:**
"Here you can see the problem clearly. Naive FedAvg achieves an F1 of 0.77 on clean data. But as soon as Client 1 applies a label-flip attack and amplifies their gradient by 15x, the global model collapses � F1 drops to 0.65 and recall falls to only 0.49. That means more than half of all intrusions are completely missed.

The culprit is a poisoned update that overwhelms all honest clients in raw magnitude."

---

## [0:45 - 1:15] THE DEFENSE � Our Approach

**Show on screen:** client_distribution.png

**Narration:**
"Here is the non-IID client distribution. Notice Client 3: 54,000 samples, but only 6% are attacks. This creates a secondary problem � even without poisoning, Client 3 biases the global model toward normal-traffic predictions.

Our solution has three layers.

First: L2 norm clipping. Every client update is bounded to a unit norm, immediately stripping Client 1's magnitude inflation.

Second: Multi-criterion anomaly detection. Each round, we score every client using three signals � norm inflation ratio, peer Euclidean distance, and cosine alignment with the honest consensus direction. Client 1's flipped gradient points in the opposite direction from all other clients, making it trivially detectable.

Third: Square-root sample weighting. Instead of weighting Client 3 at 49% of the aggregate, we use the square root of sample count, dropping their effective weight to 34% and restoring attack sensitivity."

---

## [1:15 - 1:40] ARCHITECTURE � ResNetMLP

**Show on screen:** Show README.md Architecture section (Section 3A) or a diagram**

**Narration:**
"On the model side, we upgraded from an 8-neuron baseline to a ResNetMLP: 3,905 parameters, with LayerNorm, GELU activations, and a residual skip connection from input to the hidden layer. We also replaced SGD with AdamW and added FedProx proximal regularization to prevent client drift under extreme label skew.

The model is fully TorchScript-compatible and weighs only 10.3 kilobytes."

---

## [1:40 - 2:10] RESULTS � The Before/After

**Show on screen:** f1_comparison.png (full 4-bar comparison)

**Narration:**
"Here are the results. The naive FedAvg under attack: F1 = 0.65. A previous baseline defense using simple peer trimming: F1 = 0.76. Our final defended model: F1 = 0.835.

That is a recovery of plus 0.1839 F1 � a 28% relative improvement over the poisoned baseline.

More concretely: false negatives dropped from 6,576 missed attacks with naive FedAvg, down to 3,334 with our defense � 3,242 more intrusions caught.

And the malicious client detection rate? 100% across all 8 communication rounds."

---

## [2:10 - 2:30] ROBUSTNESS � Multi-Seed and Confusion Matrix

**Show on screen:** confusion_matrix.png then multi_seed_results.csv**

**Narration:**
"The confusion matrix shows the defended model catching 9,499 true attacks while only missing 3,334 � a false negative rate of 26%.

For robustness, we evaluated across 5 random seeds. Mean F1 is 0.816 plus or minus 0.014 � tight variance. And the malicious client was correctly identified in every single round across every seed."

---

## [2:30 - 2:50] EFFICIENCY AND REPRODUCIBILITY

**Show on screen:** Terminal running `python validate_final_submission.py` or the README**

**Narration:**
"The entire pipeline is reproducible with a single command: python src/pipeline.py. No GPU required. It automatically downloads NSL-KDD, runs all four experiments, generates all figures, and exports the model_scripted.pt and submission.json files.

Running validate_final_submission.py confirms all artifacts are present and valid � expected output: READY."

---

## [2:50 - 3:00] CONCLUSION

**Show on screen:** Cover card or f1_comparison.png**

**Narration:**
"To summarize: a compact 3,905-parameter ResNetMLP, trained with AdamW and FedProx, aggregated with multi-criterion robust defense and square-root weighting � achieving F1 = 0.835 under poisoning attack with 100% malicious client detection, from a model that fits in 10 kilobytes.

Thank you."

---

## RECORDING TIPS

- Record at 1920x1080 minimum
- Use OBS Studio or Windows Game Bar (Win+G) for screen capture
- Keep file size reasonable: compress to 200-500 MB max before uploading
- Upload to YouTube as Unlisted or Public, then paste link into Kaggle
- Kaggle requires the video to be publicly accessible
