# CAIRLab Secure AI: Robust Federated Intrusion Detection with Multi-Criterion Poisoning Defense

**Track: Advanced � Poisoning Attack Detection and Defense**

---

## 1. Problem

Modern intrusion detection must operate across distributed institutions (banks, hospitals, network operators) where raw traffic logs cannot be shared due to privacy regulations. Federated Learning (FL) enables collaborative model training without centralizing data � but it introduces a critical vulnerability: any participant can manipulate the shared global model by submitting poisoned gradient updates.

This submission addresses the **CAIRLab Secure AI Hackathon 2026 Advanced Track**: build a federated intrusion detection system on the **NSL-KDD dataset** that is simultaneously resilient to non-IID data heterogeneity and active label-flip poisoning attacks.

---

## 2. Federated Learning Challenge

The challenge simulates a realistic multi-bank federation with **5 clients** assigned traffic data via Dirichlet partitioning (alpha=0.3), producing severe label skew:

| Client | Samples | Attack Rate |
|--------|---------|-------------|
| 0      | 3,040   | 96.4%       |
| 1      | 11,414  | 99.6%       |
| 2      | 27,264  | 99.9%       |
| 3      | 54,855  | **6.2%** (mostly normal traffic) |
| 4      | 14,400  | 46.5%       |

Client 3 alone contributes ~49% of all training samples but sees almost no attacks, creating a natural aggregation bias toward predicting "normal." The attack scenario adds a **15x gradient scaling label-flip attack** on Client 1.

---

## 3. Why Naive FedAvg Was Insufficient

Under the poisoning attack, naive FedAvg (WeakMLP, 345 parameters) collapsed to:

- **F1 = 0.6511** (vs. 0.7674 clean baseline)
- Recall dropped to **0.4876**: more than half of all intrusions were missed
- False negatives: **6,576 attacks undetected**

The root causes were twofold: (a) the 15x scaled poisoned update from Client 1 overwhelmed honest clients in magnitude, and (b) the dominant Client 3 normal-traffic bias suppressed attack sensitivity even without poisoning. A basic peer-distance trimming defense (E003) recovered to F1 = 0.7554, but left 4,905 false negatives.

---

## 4. Proposed Approach

We developed a three-component defense pipeline on an improved model architecture:

### A. ResNetMLP Architecture (3,905 parameters)

```
Input(41) -> Linear(32) -> LayerNorm -> GELU
          -> Linear(32) -> LayerNorm -> GELU + Skip(41->32)
          -> Linear(1)
```

Residual skip connection preserves input signal; LayerNorm stabilizes training under extreme label skew.

### B. AdamW + FedProx Local Training

- **AdamW** (lr=0.005, weight_decay=1e-4) replaces SGD for stable non-IID convergence.
- **FedProx** proximal penalty (mu=0.001): `loss += 0.5 * mu * ||w - w_global||^2` prevents client drift.

### C. Multi-Criterion Robust Aggregation

Per round, for each client update delta_i = w_i - w_global:

1. **L2 Norm Clipping**: delta_i clipped to clip_norm=1.0 (neutralizes magnitude inflation)
2. **Multi-Criterion Anomaly Scoring**:
   - Norm inflation ratio: ||delta_i|| / median(||delta_j||)
   - Pairwise peer Euclidean distance: sum_j ||delta_i - delta_j||
   - Peer cosine alignment: mean cosine similarity with all other updates
   - Combined: `score = peer_dist * norm_ratio - 2.0 * mean_cos`
   - Highest-scoring client is excluded each round
3. **Square-Root Sample Weighting**: Aggregates honest clients with weights proportional to sqrt(N_i), reducing Client 3 dominance from ~49% to ~34% effective weight.

The poisoned Client 1's label-flipped gradient points opposite to the honest consensus direction (negative cosine alignment), enabling **100% detection** across all rounds and seeds.

---

## 5. Experimental Setup

- **Dataset**: NSL-KDD (KDDTrain+.txt / KDDTest+.txt)
- **Preprocessing**: StandardScaler (41 features), LabelEncoder (3 categorical), binary label (normal=0, attack=1)
- **Holdout**: 15,000 samples reserved; evaluation on KDDTest+ (22,544 records)
- **FL config**: 8 rounds, 1 local epoch, batch size 256
- **Attack**: Client 1 label-flip + 15x gradient scaling
- **Primary seed**: 42; validated on 5 seeds: {42, 101, 777, 2024, 9999}

---

## 6. Results

### Key Result: F1 Under Attack

| Method                          | F1     | Accuracy | Recall | Precision | ROC-AUC |
|---------------------------------|--------|----------|--------|-----------|---------|
| Naive FedAvg (clean baseline)   | 0.7674 | 0.7807   | 0.6354 | 0.9686    | 0.9012  |
| **Naive FedAvg (under attack)** | **0.6511** | 0.7025 | 0.4876 | 0.9796 | 0.8995 |
| Previous defense E003           | 0.7554 | 0.7722   | 0.6178 | 0.9718    | 0.9015  |
| **Final Defended Model (ours)** | **0.8350** | **0.8335** | **0.7402** | **0.9578** | **0.9520** |

> **F1 Recovered: +0.1839 absolute (+28.2% relative) over naive FedAvg under attack**
> **+10.6% improvement over previous best defense (E003)**

### Confusion Matrix (Final Defended, KDDTest+)

|               | Predicted Normal | Predicted Attack |
|---------------|-----------------|-----------------|
| **True Normal** | TN = 9,292    | FP = 419        |
| **True Attack** | FN = 3,334    | TP = 9,499      |

False negatives reduced: **6,576 -> 3,334** (3,242 fewer missed attacks vs. FedAvg under attack).

---

## 7. Security Analysis

**Malicious Client Detection Rate: 100.0%** across all 8 rounds and all 5 seeds.

Multi-seed stability (under active attack):

| Metric         | Mean   | Std     |
|----------------|--------|---------|
| F1             | 0.8162 | +/-0.0144 |
| Accuracy       | 0.8179 | +/-0.0118 |
| Precision      | 0.9584 | +/-0.0018 |
| Recall         | 0.7110 | +/-0.0226 |
| Detection Rate | **1.0000** | +/-0.0000 |

---

## 8. Efficiency

- **Parameters**: 3,905 (vs. 345 baseline WeakMLP)
- **Model file**: 10.3 KB TorchScript (.pt)
- **Inference**: 3.82 ms for 22,544 records (0.17 us/sample)
- **Training**: ~28.8 sec / 8 rounds (CPU)
- **Communication**: ~15.3 KB/client/round

---

## 9. Reproducibility

```bash
pip install -r requirements.txt
python src/pipeline.py          # Runs E001-E004, saves all artifacts
python validate_final_submission.py  # Expected: READY
```

Seed=42. No GPU required. All outputs deterministic.

---

## 10. Limitations

- Defense assumes one malicious client per round; multi-attacker scenarios require threshold-based extension.
- Client 3 class imbalance effect persists (local F1 on Client 3 test subset: 0.766).
- Simulated poisoning; adaptive attackers may evade cosine alignment detection.

---

## 11. Conclusion

By combining a residual MLP architecture, AdamW+FedProx local training, and multi-criterion robust aggregation with square-root sample weighting, we recovered **+0.1839 F1** under a 15x label-flip poisoning attack, achieving **F1 = 0.8350** with **100% malicious client detection rate**. The solution is compact (3,905 parameters, 10.3 KB), CPU-executable, and fully reproducible from a single command.
