# Secure AI Hackathon 2026 � Final Submission Checklist

---

## BASIC DETAILS

- [x] **Title** � `CAIRLab Secure AI: Robust Federated Intrusion Detection with Multi-Criterion Poisoning Defense`  
  *Source: `writeup/TITLE.txt`*
- [x] **Subtitle** � `ResNetMLP + Multi-Criterion Robust Aggregation recovers +0.1839 F1 under 15x label-flip poisoning attack across 5 non-IID federated clients � 100% malicious client detection rate`  
  *Source: `writeup/SUBTITLE.txt`*
- [ ] **Card and Thumbnail Image** � 560x280 pixels  
  *Status: Generated as `writeup/cover_card.jpg` � must be cropped/resized to exactly 560x280 before upload*
- [x] **Submission Track** � Advanced Track (Poisoning Attack Detection and Defense)  
  *Source: `submission.json` ? `"track": "advanced"`*

---

## CONTENT

- [x] **Project Description** � Prepared in `writeup/WRITEUP_FINAL.md`  
  - Word count: ~1,200 words (under 1,500 limit) ?
  - Contains before/after F1 comparison: 0.6511 ? 0.8350 ?
  - Uses only measured results from `final_metrics.json` / `submission.json` ?
  - Correct track selected: Advanced ?
  - No unsupported claims ?

---

## MEDIA GALLERY

- [x] **Cover image** � `writeup/cover_card.jpg`  
  *Must be resized to exactly 560x280 px before uploading*
- [x] **F1 Comparison chart** � `final_submission/figures/f1_comparison.png` ?
- [x] **F1 over rounds (convergence)** � `final_submission/figures/f1_over_rounds.png` ?
- [x] **Client distribution** � `final_submission/figures/client_distribution.png` ?
- [x] **Confusion matrix** � `final_submission/figures/confusion_matrix.png` ?
- [ ] **Architecture diagram** � Not yet generated as a standalone image; README contains text diagram

---

## SUBMISSION MATERIALS

- [x] **Final fully-run Day 2 notebook** � `final_submission/final_notebook.ipynb` ?  
  *Note: notebook contains pre-written cells but needs to be RUN on Kaggle so cell outputs are visible*
- [ ] **Public video <= 3 minutes** � Script prepared in `writeup/VIDEO_SCRIPT.md`; video not yet recorded
- [ ] **Public GitHub project link** � Repository must be made public and link submitted
- [x] **`model_scripted.pt`** � `final_submission/model_scripted.pt` (28 KB on disk) ?
- [x] **`submission.json`** � `final_submission/submission.json` ?
- [x] **README** � `README.md` (6.9 KB, comprehensive) ?
- [x] **Reproduction instructions** � Included in `README.md` Section 6 ?

---

## WRITEUP QUALITY

- [x] Word count <= 1,500 words ?
- [x] Clear before/after F1 comparison: **0.6511 (attack) ? 0.8350 (defended)** ?
- [x] Correct track selected: **Advanced** ?
- [x] All results from actual measurements (no invented metrics) ?
- [x] No unsupported claims ?
- [x] Confusion matrix included ?
- [x] Multi-seed stability results included ?
- [x] Reproducibility instructions included ?
- [x] Limitations stated ?

---

## OPEN ACTION ITEMS

| Item | Status | Action Required |
|------|--------|----------------|
| Card/Thumbnail | Partial | Resize `writeup/cover_card.jpg` to exactly 560x280 px |
| Architecture diagram image | Missing | Optional � add standalone .png diagram |
| Video | Missing | Record 3-minute screen recording following `VIDEO_SCRIPT.md` |
| GitHub repository | Not yet public | Push files to GitHub and set repository to Public |
| Notebook cell outputs | Missing | Run `final_notebook.ipynb` on Kaggle with outputs visible |
